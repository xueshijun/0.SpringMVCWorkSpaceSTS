package sy.service;

public interface RepairServiceI {

	public void repair();

}
